/**
 * @module
 * LinearRouter for Hono.
 */

export { LinearRouter } from './router'
