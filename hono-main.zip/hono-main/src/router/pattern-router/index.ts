/**
 * @module
 * PatternRouter for Hono.
 */

export { PatternRouter } from './router'
