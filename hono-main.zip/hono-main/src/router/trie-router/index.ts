/**
 * @module
 * TrieRouter for Hono.
 */

export { TrieRouter } from './router'
