/**
 * @module
 * SmartRouter for Hono.
 */

export { SmartRouter } from './router'
