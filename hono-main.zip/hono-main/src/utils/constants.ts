/**
 * Constant used to mark a composed handler.
 */
export const COMPOSED_HANDLER = '__COMPOSED_HANDLER'
