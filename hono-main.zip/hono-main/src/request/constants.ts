export const GET_MATCH_RESULT: symbol = Symbol()
