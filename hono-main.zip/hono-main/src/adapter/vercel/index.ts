/**
 * @module
 * Vercel Adapter for Hono.
 */

export { handle } from './handler'
export { getConnInfo } from './conninfo'
