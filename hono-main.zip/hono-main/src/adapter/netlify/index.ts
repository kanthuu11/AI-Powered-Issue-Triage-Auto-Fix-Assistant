/**
 * @module
 * Netlify Adapter for Hono.
 */

export * from './mod'
