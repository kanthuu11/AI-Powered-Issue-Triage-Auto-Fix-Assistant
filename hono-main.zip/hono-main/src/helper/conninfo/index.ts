/**
 * @module
 * ConnInfo Helper for Hono.
 */

export type { AddressType, NetAddrInfo, ConnInfo, GetConnInfo } from './types'
