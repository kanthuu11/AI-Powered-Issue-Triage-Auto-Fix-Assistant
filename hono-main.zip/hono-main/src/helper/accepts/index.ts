/**
 * @module
 * Accepts Helper for Hono.
 */

export { accepts } from './accepts'
